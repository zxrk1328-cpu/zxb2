window.ZXRKBTW_BOT_CONFIG = {
  clientId: "1511630216903131197",
  permissions: "8",
  loginUrl: "/auth/discord",
  logoutUrl: "/api/logout",
  supportServer: "https://discord.gg/n4k597UTUC",
  dashboardUrl: "/dashboard",
  botName: "ZXRKBTW Bot",
  ownerDiscordUserId: "1018850926209015808",

  adminCommandGroups: [
    "Moderation", "AutoMod", "Tickets", "Logs", "Levels", "Economy", "Giveaways", "Suggestions", "Server settings"
  ],
  ownerCommandGroups: [
    "Global bot control", "Guild override", "Premium grants", "Blacklist/whitelist", "Maintenance mode", "Broadcasts", "Database tools", "Command deploy/reload"
  ]
};
